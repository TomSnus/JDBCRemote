CREATE VIEW PERSONAL1 AS select persnr, name, ort as wohnung, vorgesetzt as Chef
from personal
/
