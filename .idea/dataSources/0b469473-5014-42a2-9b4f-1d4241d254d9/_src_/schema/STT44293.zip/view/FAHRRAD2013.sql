CREATE VIEW FAHRRAD2013 AS select a.anr, a.Bezeichnung as Fahrrad, k.name, sum(ap.gesamtpreis*ap.anzahl) as Umsatz
from auftragsposten ap join artikel a on ap.artnr=a.anr join  auftrag au on au.auftrnr=ap.auftrnr join kunde k on au.kundnr=k.nr
where a.anr<200000 and au.datum between date '2013-01-01' and date '2013-12-31'
group by a.anr, a.Bezeichnung, k.name
/
