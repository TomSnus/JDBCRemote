CREATE PROCEDURE PROZEDURE_FACT1 AS 


  DROP TABLE Fact1;
  
  DROP SEQUENCE Fact1_counter;
  
  
  CREATE TABLE Fact1 (
    FId       INTEGER Constraint PK_Fact PRIMARY KEY, 
    OrderId   INTEGER Constraint FK_Fact_O References orders, 
    CustId    INTEGER Constraint FK_FACT_C References customer,
    SalesDate DATE,
    ArtId     INTEGER Constraint FK_FACT_A References article,
    Price     NUMERIC(5,2),
    Quantity  INTEGER,  
    Month     INTEGER,
    Year      INTEGER
  );
  
  CREATE SEQUENCE Fact1_counter
    INCREMENT BY 1 
    START WITH 1;
     BEGIN
    INSERT INTO Fact1 (FId, OrderId, CustId, SalesDate, ArtId, Price, Quantity, Month, Year) 
    SELECT Fact1_counter.nextval,ordid, custid, orderdate, artid, totalprice/quantity, quantity, to_char(orderdate, 'MM'), to_char(orderdate, 'YYYY')
    FROM orders NATURAL INNER JOIN  orderposition
    
    COMMIT;

  
END PROZEDURE_FACT1;
/
