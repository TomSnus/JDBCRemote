CREATE TRIGGER PERSNR
BEFORE INSERT
  ON PERSONAL
FOR EACH ROW
  begin 
:neu.persnr := personalnrincrement.nextval;
end;
/
