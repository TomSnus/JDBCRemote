CREATE TRIGGER AUFTRAGSPREIS_TRIGGER
BEFORE INSERT OR UPDATE
  ON AUFTRAGSPOSTEN
FOR EACH ROW
  Declare 
listenpreis numeric(8,2);
Begin
select :neu.Anzahl*Preis
into listenpreis
from artikel where anr=:neu.Artnr;
if(:neu.Gesamtpreis > listenpreis)
then
:neu.gesamtpreis:=listenpreis;
dbms_output.put_line('Preis in Posnr'||:neu.posnr||'ge�ert');
end if;
end;
/
