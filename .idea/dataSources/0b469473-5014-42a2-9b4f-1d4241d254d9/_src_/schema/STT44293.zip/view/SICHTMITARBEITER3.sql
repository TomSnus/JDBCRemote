CREATE VIEW SICHTMITARBEITER3 AS select persnr, name, strasse, plz, ort, gebdatum, stand, vorgesetzt, gehalt, beurteilung, aufgabe from Personal where persnr=3
union
select null, null, Strasse, plz, ort, null, null, null, null, null, null from Personal where Persnr!=3
/
