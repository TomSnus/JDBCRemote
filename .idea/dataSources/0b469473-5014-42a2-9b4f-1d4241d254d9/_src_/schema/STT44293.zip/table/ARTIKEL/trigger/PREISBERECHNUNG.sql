CREATE TRIGGER PREISBERECHNUNG
BEFORE INSERT OR UPDATE
  ON ARTIKEL
FOR EACH ROW
  begin 
:neu.steuer := :neu.netto*0.19;
:neu.preis := :neu.netto*1.19;
end;
/
